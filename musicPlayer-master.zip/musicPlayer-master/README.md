# musicPlayer
html音乐播放器

## 演示效果图：
<img src="https://github.com/zoyoy1203/musicPlayer/blob/master/others/img16.gif" />